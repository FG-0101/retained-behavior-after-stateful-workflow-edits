"""Persistent SQLite replays with no reset between edited and retained tasks."""
import sqlite3,json,itertools
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def chain(kind,initial,version,word):
 statements=[]; records=[]
 with sqlite3.connect(':memory:') as db:
  db.set_trace_callback(statements.append)
  db.executescript('CREATE TABLE memory(x INTEGER NOT NULL,y INTEGER NOT NULL); CREATE VIEW alias AS SELECT x AS shared FROM memory;')
  db.execute('INSERT INTO memory VALUES (?,?)',initial)
  if kind=='dead': db.execute('UPDATE memory SET y=?',(version,))
  elif kind=='parity': db.execute('UPDATE memory SET x=?,y=?',(version,version))
  else: db.execute('UPDATE memory SET x=?',(version,))
  records.append({'task':'edit','output':'ok','state':db.execute('SELECT x,y FROM memory').fetchone()})
  for a in word:
   if kind=='delay' and a=='tick': db.execute('UPDATE memory SET y=min(y+1,7)'); out='tick'
   elif kind=='delay':
    row=db.execute('SELECT x,y FROM memory').fetchone(); out=row[0] if row[1]==7 else 'pending'
   elif kind=='alias': out=db.execute('SELECT shared FROM alias').fetchone()[0]
   elif kind=='guard': out='allow' if db.execute('SELECT x FROM memory').fetchone()[0] else 'deny'
   elif kind=='parity': x,y=db.execute('SELECT x,y FROM memory').fetchone(); out=x^y
   else: out=db.execute('SELECT x FROM memory').fetchone()[0]
   records.append({'task':a,'output':out,'state':db.execute('SELECT x,y FROM memory').fetchone()})
 return {'initial':initial,'version':version,'word':word,'records':records,'sql_trace':statements,'resets_between_tasks':0}

rows=[]; counts={'unsafe_witnesses_replayed':0,'safe_chains_replayed':0,'disagreements':0}
for file in sorted((ROOT/'native').glob('*.json')):
 r=json.loads(file.read_text()); c=r['certificate']; kind=r['case']
 if not c['safe']:
  ids=[i for i in r['initial_ids'] if [r['versions'][0][i]['edit'][1],r['versions'][1][i]['edit'][1]]==c['seed']]
  assert ids
  initial=r['states'][ids[0]]; word=c['word']; pair=[chain(kind,initial,v,word) for v in (0,1)]
  for v in (0,1):
   model_outputs=r['witness_outputs'][v]; actual=[x['output'] for x in pair[v]['records'][1:]]; assert actual==model_outputs
  assert [x['output'] for x in pair[0]['records'][1:]]!=[x['output'] for x in pair[1]['records'][1:]]
  rows.extend(pair); counts['unsafe_witnesses_replayed']+=1
 else:
  for i in r['initial_ids']:
   for k in range(5):
    word=['read']*k; pair=[chain(kind,r['states'][i],v,word) for v in (0,1)]
    assert [x['output'] for x in pair[0]['records'][1:]]==[x['output'] for x in pair[1]['records'][1:]]
    rows.extend(pair); counts['safe_chains_replayed']+=1
(ROOT/'native/persistent_chains.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows))
counts.update(native_connections=len(rows),no_reset_within_connection=True,safe_chain_scope='length 0 to 4 from all declared initial states; full guarantee from finite certificate')
(ROOT/'results/native_chains_summary.json').write_text(json.dumps(counts,indent=2)+'\n'); print(json.dumps(counts,indent=2))
