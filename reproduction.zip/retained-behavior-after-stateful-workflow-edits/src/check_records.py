"""Recheck the serialized records with code separate from certificate.py."""
import itertools,gzip,json,random,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def decode(index,base,n):
 out=[0]*n
 for i in range(n-1,-1,-1): out[i]=index%base; index//=base
 assert index==0
 return out

def refinement(table):
 relation={(x,y) for x in range(len(table)) for y in range(len(table))}
 while True:
  nxt={(x,y) for x,y in relation if all(table[x][a][0]==table[y][a][0] and (table[x][a][1],table[y][a][1]) in relation for a in table[x])}
  if nxt==relation: return relation
  relation=nxt

def outputs(t,s,word):
 out=[]
 for a in word:
  o,s=t[s][a]; out.append(o)
 return out

def verify(left,right,seeds,safe,pairs,word,seed):
 if safe:
  assert set(seeds)<=pairs
  for x,y in pairs:
   for a in left[x]:
    o,n=left[x][a]; p,m=right[y][a]; assert o==p and (n,m) in pairs
 else:
  assert tuple(seed) in seeds
  assert outputs(left,seed[0],word)!=outputs(right,seed[1],word)
  # All shorter words are checked independently, for every seed.
  for k in range(len(word)):
   for w in itertools.product(sorted(left[0]),repeat=k):
    for x,y in seeds: assert outputs(left,x,w)==outputs(right,y,w)

count=0; sums={2:{'safe':0,'unsafe':0},3:{'safe':0,'unsafe':0}}; known={}
with gzip.open(ROOT/'results/exhaustive_cases.jsonl.gz','rt') as f:
 for line in f:
  r=json.loads(line); n=r['n']; cells=decode(r['retained_table_id'],2*n,n)
  table=[{'r':(c//n,c%n)} for c in cells]
  old=decode(r['old_edit_id'],n,n); new=decode(r['new_edit_id'],n,n)
  assert old!=new; seeds=list(zip(old,new)); pairs={(x,y) for x in range(n) for y in range(n) if r['pair_mask']>>(x*n+y)&1}
  verify(table,table,seeds,r['safe'],pairs,r['word'],r['seed'])
  key=(n,r['retained_table_id'])
  if key not in known: known[key]=refinement(table)
  assert r['safe']==all(z in known[key] for z in seeds)
  sums[n]['safe' if r['safe'] else 'unsafe']+=1; count+=1
assert count==151824
native=0
for p in sorted((ROOT/'native').glob('*.json')):
 r=json.loads(p.read_text()); labels=r['labels']; vs=r['versions']; left=[{a:tuple(row[a]) for a in labels} for row in vs[0]]; right=[{a:tuple(row[a]) for a in labels} for row in vs[1]]; c=r['certificate']
 verify(left,right,list(map(tuple,r['seeds'])),c['safe'],set(map(tuple,c['pairs'])),c['word'],c.get('seed')); native+=1
result={'serialized_exhaustive_records_verified':count,'native_certificates_verified':native,'summary_counts':sums,'minimality':'all shorter words enumerated','disagreements':0}
(ROOT/'results/independent_readback.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
