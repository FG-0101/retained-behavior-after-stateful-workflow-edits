"""Finite deterministic retained-continuation certificates. Python stdlib only."""
from collections import deque

def certify(left, right, seeds):
    """Tables: state -> label -> (observation,next_state). Shortest witness."""
    queue=deque(); paths={}
    for pair in sorted(set(map(tuple,seeds))):
        paths[pair]=(); queue.append(pair)
    labels=tuple(sorted(left[0]))
    assert labels==tuple(sorted(right[0]))
    while queue:
        x,y=queue.popleft()
        for label in labels:
            ox,nx=left[x][label]; oy,ny=right[y][label]
            word=paths[(x,y)]+(label,)
            if ox!=oy:
                return {'safe':False,'seed':trace_seed(left,right,seeds,word),
                        'word':list(word),'pairs':sorted(paths),'mismatch':[ox,oy]}
            pair=(nx,ny)
            if pair not in paths:
                paths[pair]=word; queue.append(pair)
    return {'safe':True,'pairs':sorted(paths),'word':None}

def run(table,state,word):
    outputs=[]
    for label in word:
        out,state=table[state][label]; outputs.append(out)
    return tuple(outputs),state

def trace_seed(left,right,seeds,word):
    for x,y in sorted(set(map(tuple,seeds))):
        if run(left,x,word)[0]!=run(right,y,word)[0]: return [x,y]
    raise AssertionError('BFS produced no distinguishing seed')

def validate_certificate(left,right,seeds,record):
    """Local certificate obligations, independently rechecked after serialization."""
    if record['safe']:
        relation=set(map(tuple,record['pairs']))
        assert set(map(tuple,seeds))<=relation
        for x,y in relation:
            for a in left[x]:
                ox,nx=left[x][a]; oy,ny=right[y][a]
                assert ox==oy and (nx,ny) in relation
    else:
        assert tuple(record['seed']) in set(map(tuple,seeds))
        assert run(left,record['seed'][0],record['word'])[0]!=run(right,record['seed'][1],record['word'])[0]
        assert len(record['word'])<=len(left)*len(right)

def partition_equivalence(table):
    """Moore refinement computes equivalence classes of the retained machine."""
    blocks=[0]*len(table)
    while True:
        signatures=[tuple((a,out,blocks[nxt]) for a,(out,nxt) in sorted(row.items())) for row in table]
        names={}; updated=[]
        for signature in signatures:
            if signature not in names: names[signature]=len(names)
            updated.append(names[signature])
        if updated==blocks: return blocks
        blocks=updated
