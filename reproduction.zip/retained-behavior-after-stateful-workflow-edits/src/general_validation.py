"""Check unequal versions and changes to the action alphabet."""
import random,json,copy,itertools
from pathlib import Path
from certificate import certify,validate_certificate,partition_equivalence
ROOT=Path(__file__).resolve().parents[1]; rng=random.Random(731042)
records=[]
for case in range(1024):
 n=4; labels=('a','b'); tables=[[{a:(rng.randrange(2),rng.randrange(n)) for a in labels} for s in range(n)] for _ in (0,1)]
 left,right=tables; seeds=[(rng.randrange(n),rng.randrange(n)) for _ in range(2)]
 c=certify(left,right,seeds); validate_certificate(left,right,seeds,c)
 combined=left+[{a:(o,nxt+n) for a,(o,nxt) in row.items()} for row in right]
 blocks=partition_equivalence(combined); assert c['safe']==all(blocks[x]==blocks[y+n] for x,y in seeds)
 records.append({'case':case,'left':left,'right':right,'seeds':seeds,'certificate':c})
(ROOT/'results/general_cases.json').write_text(json.dumps(records,indent=2)+'\n')
# Action a leaves the dormant bit unobserved; observer b exposes the changed bit.
a=[{'a':(0,0)},{'a':(0,1)}]; c=certify(a,a,[(0,1)]); assert c['safe']
b=[{'a':(0,0),'b':(0,0)},{'a':(0,1),'b':(1,1)}]; d=certify(b,b,[(0,1)]); assert not d['safe'] and d['word']==['b']
# Certificate validator must reject missing seed and broken closure.
mutation_rejections=0
for broken in ({'safe':True,'pairs':[],'word':None},{'safe':True,'pairs':[(0,1)],'word':None}):
 try: validate_certificate(b,b,[(0,1)],broken)
 except AssertionError: mutation_rejections+=1
 else: raise AssertionError('invalid certificate admitted')
result={'different_version_cases':1024,'random_seed':731042,'safe':sum(r['certificate']['safe'] for r in records),'disagreements':0,'observer_extension_rejects':True,'invalid_certificates_rejected':mutation_rejections}
(ROOT/'results/general_summary.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
