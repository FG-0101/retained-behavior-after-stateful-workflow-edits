"""Constructed SQLite workflows. All snapshots and transitions are saved."""
import sqlite3,itertools,json
from pathlib import Path
from certificate import certify,validate_certificate,partition_equivalence,run
ROOT=Path(__file__).resolve().parents[1]

def invoke(kind,state,label,version):
    with sqlite3.connect(':memory:') as db:
        db.execute('CREATE TABLE memory(x INTEGER NOT NULL,y INTEGER NOT NULL)')
        db.execute('INSERT INTO memory VALUES (?,?)',state)
        db.execute('CREATE VIEW alias AS SELECT x AS shared FROM memory')
        if label=='edit':
            if kind=='dead': db.execute('UPDATE memory SET y=?',(version,))
            elif kind=='parity': db.execute('UPDATE memory SET x=?,y=?',(version,version))
            else: db.execute('UPDATE memory SET x=?',(version,))
            out='ok'
        elif kind=='alias': out=db.execute('SELECT shared FROM alias').fetchone()[0]
        elif kind=='guard':
            out='allow' if db.execute('SELECT x FROM memory').fetchone()[0] else 'deny'
        elif kind=='dead': out=db.execute('SELECT x FROM memory').fetchone()[0]
        elif kind=='parity':
            x,y=db.execute('SELECT x,y FROM memory').fetchone(); out=x^y
        elif kind=='delay':
            x,y=db.execute('SELECT x,y FROM memory').fetchone()
            if label=='tick': db.execute('UPDATE memory SET y=?',(min(y+1,7),)); out='tick'
            else: out=x if y==7 else 'pending'
        else: out=db.execute('SELECT x FROM memory').fetchone()[0]
        final=tuple(db.execute('SELECT x,y FROM memory').fetchone())
        return out,final

def main():
  summaries=[]
  for kind in ('shared','alias','guard','dead','parity','delay'):
    states=list(itertools.product(range(2),range(8) if kind=='delay' else range(2)))
    ids={s:i for i,s in enumerate(states)}; labels=('tick','read') if kind=='delay' else ('read',)
    versions=[]; raw=[]; transitions=0
    for version in (0,1):
      table=[]
      for state in states:
        row={}
        for label in ('edit',)+labels:
          out,nxt=invoke(kind,state,label,version)
          assert nxt in ids
          row[label]=(out,ids[nxt]); raw.append({'version':version,'state':state,'label':label,'output':out,'next':nxt}); transitions+=1
        table.append(row)
      versions.append(table)
    left=[{a:r[a] for a in labels} for r in versions[0]]; right=[{a:r[a] for a in labels} for r in versions[1]]
    assert left==right
    initial_ids=[i for i,s in enumerate(states) if kind!='delay' or s[1]==0]
    seeds=[(versions[0][i]['edit'][1],versions[1][i]['edit'][1]) for i in initial_ids]
    cert=certify(left,right,seeds); validate_certificate(left,right,seeds,cert)
    blocks=partition_equivalence(left); assert cert['safe']==all(blocks[x]==blocks[y] for x,y in seeds)
    seed=cert.get('seed'); outs=[run(t,s,cert['word'])[0] for t,s in zip((left,right),seed)] if seed else None
    record={'case':kind,'states':states,'labels':labels,'versions':versions,'initial_ids':initial_ids,'seeds':seeds,'certificate':cert,'witness_outputs':outs,'reset_retained_tests_pass':True,'sqlite_transitions':transitions,'database':'in-memory SQLite','sqlite_version':sqlite3.sqlite_version}
    (ROOT/'native'/f'{kind}.json').write_text(json.dumps(record,indent=2)+'\n')
    (ROOT/'native'/f'{kind}_transitions.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in raw))
    summaries.append({'case':kind,'states':len(states),'safe':cert['safe'],'witness_length':len(cert['word']) if cert['word'] else None,'witness':cert['word'],'sqlite_transitions':transitions,'pair_count':len(cert['pairs'])})
  assert sum(x['safe'] for x in summaries)==2
  result={'cases':summaries,'total_transitions':sum(x['sqlite_transitions'] for x in summaries),'declared_state_coverage':'all states for each constructed finite store','sqlite_version':sqlite3.sqlite_version}
  (ROOT/'results/native_summary.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
if __name__=='__main__': main()
