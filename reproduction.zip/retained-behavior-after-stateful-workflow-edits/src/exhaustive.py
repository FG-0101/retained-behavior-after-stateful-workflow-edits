"""Complete classes: n=2,3; one retained label; binary observations."""
import itertools,json,gzip,time,sys
from pathlib import Path
from certificate import certify,validate_certificate,partition_equivalence
ROOT=Path(__file__).resolve().parents[1]

def main():
    started=time.monotonic(); aggregates=[]
    with gzip.open(ROOT/'results/exhaustive_cases.jsonl.gz','wt',encoding='utf-8') as f:
      for n in (2,3):
        stats=dict(n=n,cases=0,safe=0,unsafe=0,reset_false_accepts=0,equality_false_rejects=0,depth1_false_accepts=0,depth2_false_accepts=0,oracle_disagreements=0,certificate_failures=0,max_witness_length=0,shortest_witness_histogram={})
        edits=list(itertools.product(range(n),repeat=n))
        for rid,cells in enumerate(itertools.product(range(2*n),repeat=n)):
          table=[{'r':(c//n,c%n)} for c in cells]
          partition=partition_equivalence(table)
          for lid,old in enumerate(edits):
            for eid,new in enumerate(edits):
              if old==new: continue
              seeds=list(zip(old,new)); cert=certify(table,table,seeds)
              validate_certificate(table,table,seeds,cert)
              oracle=all(partition[x]==partition[y] for x,y in seeds)
              assert oracle==cert['safe'],(n,rid,lid,eid)
              stats['cases']+=1
              safe=cert['safe']; stats['safe' if safe else 'unsafe']+=1
              if not safe:
                stats['reset_false_accepts']+=1
                length=len(cert['word']); stats['max_witness_length']=max(stats['max_witness_length'],length)
                hist=stats['shortest_witness_histogram']; hist[str(length)]=hist.get(str(length),0)+1
                stats['depth1_false_accepts']+=length>1; stats['depth2_false_accepts']+=length>2
              else: stats['equality_false_rejects']+=any(x!=y for x,y in seeds)
              mask=sum(1<<(x*n+y) for x,y in cert['pairs'])
              f.write(json.dumps({'n':n,'retained_table_id':rid,'old_edit_id':lid,'new_edit_id':eid,'safe':safe,'pair_mask':mask,'seed':cert.get('seed'),'word':cert['word']},separators=(',',':'))+'\n')
        expected=(2*n)**n*n**n*(n**n-1)
        assert stats['cases']==expected
        aggregates.append(stats); print(json.dumps(stats),flush=True)
    result={'complete_enumeration':True,'results':aggregates,'total_cases':sum(x['cases'] for x in aggregates),'elapsed_seconds':time.monotonic()-started,'oracle':'independent partition refinement','random_sampling':False}
    (ROOT/'results/exhaustive_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print('FINISHED',result['total_cases'],flush=True)
if __name__=='__main__': main()
