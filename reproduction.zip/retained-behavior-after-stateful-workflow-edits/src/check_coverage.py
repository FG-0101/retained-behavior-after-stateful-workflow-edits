"""Check that every canonical input appears exactly once and recheck the general-version records."""
import json,gzip,itertools
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
seen=set(); counts={2:0,3:0}
with gzip.open(ROOT/'results/exhaustive_cases.jsonl.gz','rt') as f:
 for line in f:
  r=json.loads(line); n=r['n']; rid=r['retained_table_id']; old=r['old_edit_id']; new=r['new_edit_id']
  assert n in counts and 0<=rid<(2*n)**n and 0<=old<n**n and 0<=new<n**n and old!=new
  key=(n,rid,old,new); assert key not in seen; seen.add(key); counts[n]+=1
for n in counts: assert counts[n]==(2*n)**n*n**n*(n**n-1)

def run(t,s,word):
 out=[]
 for a in word: o,s=t[s][a]; out.append(o)
 return out

def equivalent_pairs(left,right):
 pairs={(x,y) for x in range(len(left)) for y in range(len(right))}
 while True:
  updated={(x,y) for x,y in pairs if all(left[x][a][0]==right[y][a][0] and (left[x][a][1],right[y][a][1]) in pairs for a in left[x])}
  if updated==pairs: return pairs
  pairs=updated

rows=json.loads((ROOT/'results/general_cases.json').read_text()); assert len(rows)==1024
for r in rows:
 left,right=r['left'],r['right']; seeds=list(map(tuple,r['seeds'])); c=r['certificate']; eq=equivalent_pairs(left,right)
 assert c['safe']==all(s in eq for s in seeds)
 if not c['safe']:
  assert tuple(c['seed']) in seeds
  assert run(left,c['seed'][0],c['word'])!=run(right,c['seed'][1],c['word'])
  for k in range(len(c['word'])):
   for word in itertools.product(sorted(left[0]),repeat=k):
    assert all(run(left,x,word)==run(right,y,word) for x,y in seeds)
result={'complete_unique_input_coverage':True,'canonical_cases':len(seen),'per_n':counts,'general_version_records_read_back':len(rows),'general_shortest_witnesses_independently_verified':sum(not r['certificate']['safe'] for r in rows),'oracle':'greatest fixed point of output-agreeing cross-version pairs','disagreements':0}
(ROOT/'results/full_coverage.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
